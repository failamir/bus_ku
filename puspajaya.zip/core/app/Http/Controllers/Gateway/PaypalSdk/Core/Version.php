<?php

namespace App\Http\Controllers\Gateway\PaypalSdk\Core;

class Version
{
    const VERSION = "1.0.1";
}
