
<?php $__env->startSection('content'); ?>
<?php
$counters = App\Models\Counter::get();
?>
<div class="ticket-search-bar bg_img padding-top" style="background: url(<?php echo e(getImage('assets/templates/basic/images/bg/inner.jpg')); ?>) left center;">
    <div class="container">
        <div class="bus-search-header">
            <form action="<?php echo e(route('search')); ?>" class="ticket-form ticket-form-two row g-3 justify-content-center">
                <div class="col-md-4 col-lg-3">
                    <div class="form--group">
                        <i class="las la-location-arrow"></i>
                        <select name="pickup" class="form--control select2">
                            <option value=""><?php echo app('translator')->get('Pickup Point'); ?></option>
                            <?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($counter->id); ?>" <?php if(request()->pickup == $counter->id): ?> selected <?php endif; ?>><?php echo e(__($counter->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="form--group">
                        <i class="las la-map-marker"></i>
                        <select name="destination" class="form--control select2">
                            <option value=""><?php echo app('translator')->get('Dropping Point'); ?></option>
                            <?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($counter->id); ?>" <?php if(request()->destination == $counter->id): ?> selected <?php endif; ?>><?php echo e(__($counter->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="form--group">
                        <i class="las la-calendar-check"></i>
                        <input type="text" name="date_of_journey" class="form--control datepicker" placeholder="<?php echo app('translator')->get('Date of Journey'); ?>" autocomplete="off" value="<?php echo e(request()->date_of_journey); ?>">
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="form--group">
                        <button><?php echo app('translator')->get('Find Tickets'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Ticket Search Starts -->


<!-- Ticket Section Starts Here -->
<section class="ticket-section padding-bottom section-bg">
    <div class="container">
        <div class="row gy-5">
            <div class="col-lg-3">
                <form action="<?php echo e(route('search')); ?>" id="filterForm">
                    <div class="ticket-filter">
                        <div class="filter-header filter-item">
                            <h4 class="title mb-0"><?php echo app('translator')->get('Filter'); ?></h4>
                            <button type="reset" class="reset-button h-auto"><?php echo app('translator')->get('Reset All'); ?></button>
                        </div>
                        <?php if($fleetType): ?>
                        <div class="filter-item">
                            <h5 class="title"><?php echo app('translator')->get('Vehicle Type'); ?></h5>
                            <ul class="bus-type">
                                <?php $__currentLoopData = $fleetType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fleet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="custom--checkbox">
                                    <input name="fleetType[]" class="search" value="<?php echo e($fleet->id); ?>" id="<?php echo e($fleet->name); ?>" type="checkbox" <?php if(request()->fleetType): ?>
                                    <?php $__currentLoopData = request()->fleetType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item == $fleet->id): ?>
                                    checked
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> >
                                    <label for="<?php echo e($fleet->name); ?>"><span><i class="las la-bus"></i><?php echo e(__($fleet->name)); ?></span></label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php if($routes): ?>
                        <div class="filter-item">
                            <h5 class="title"><?php echo app('translator')->get('Routes'); ?></h5>
                            <ul class="bus-type">
                                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="custom--checkbox">
                                    <input name="routes[]" class="search" value="<?php echo e($route->id); ?>" id="route.<?php echo e($route->id); ?>" type="checkbox" <?php if(request()->routes): ?>
                                    <?php $__currentLoopData = request()->routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item == $route->id): ?>
                                    checked
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> >
                                    <label for="route.<?php echo e($route->id); ?>"><span><span><i class="las la-road"></i> <?php echo e(__($route->name)); ?> </span></label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php if($schedules): ?>
                        <div class="filter-item">
                            <h5 class="title"><?php echo app('translator')->get('Schedules'); ?></h5>
                            <ul class="bus-type">
                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="custom--checkbox">
                                    <input name="schedules[]" class="search" value="<?php echo e($schedule->id); ?>" id="schedule.<?php echo e($schedule->id); ?>" type="checkbox" <?php if(request()->schedules): ?>
                                    <?php $__currentLoopData = request()->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item == $schedule->id): ?>
                                    checked
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>>
                                    <label for="schedule.<?php echo e($schedule->id); ?>"><span><span><i class="las la-clock"></i> <?php echo e(showDateTime($schedule->start_from, 'h:i a').' - '. showDateTime($schedule->end_at, 'h:i a')); ?> </span></label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            <div class="col-lg-9">
                <div class="ticket-wrapper">
                    <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    $start = Carbon\Carbon::parse($trip->schedule->start_from);
                    $end = Carbon\Carbon::parse($trip->schedule->end_at);
                    $diff = $start->diff($end);
                    $ticket = App\Models\TicketPrice::where('fleet_type_id', $trip->fleetType->id)->where('vehicle_route_id', $trip->route->id)->first();
                    ?>


                    <div class="ticket-item">
                        <div class="ticket-item-inner">
                            <h5 class="bus-name"><?php echo e(__($trip->title)); ?></h5>
                            <span class="bus-info"><?php echo app('translator')->get('Seat Layout - '); ?> <?php echo e(__($trip->fleetType->seat_layout)); ?></span>
                            <span class="ratting"><i class="las la-bus"></i><?php echo e(__($trip->fleetType->name)); ?></span>
                        </div>
                        <div class="ticket-item-inner travel-time">
                            <div class="bus-time">
                                <p class="time"><?php echo e(showDateTime($trip->schedule->start_from, 'h:i A')); ?></p>
                                <p class="place"><?php echo e(__($trip->startFrom->name)); ?></p>
                            </div>
                            <div class=" bus-time">
                                <i class="las la-arrow-right"></i>
                                <p><?php echo e($diff->format('%H:%I min')); ?></p>
                            </div>
                            <div class=" bus-time">
                                <p class="time"><?php echo e(showDateTime($trip->schedule->end_at, 'h:i A')); ?></p>
                                <p class="place"><?php echo e(__($trip->endTo->name)); ?></p>
                            </div>
                        </div>
                        <div class="ticket-item-inner book-ticket">
                            <p class="rent mb-0"><?php echo e(__($general->cur_sym)); ?><?php echo e(showAmount($ticket->price)); ?></p>
                            <?php if($trip->day_off): ?>
                            <div class="seats-left mt-2 mb-3 fs--14px">
                                <?php echo app('translator')->get('Off Days'); ?>: <div class="d-inline-flex flex-wrap" style="gap:5px">
                                    <?php $__currentLoopData = $trip->day_off; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge--primary"><?php echo e(__(showDayOff($item))); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php else: ?>
                                <?php echo app('translator')->get('Every day available'); ?>
                                <?php endif; ?></div>
                            <a class="btn btn--base" href="<?php echo e(route('ticket.seats', [$trip->id, slug($trip->title)])); ?>"><?php echo app('translator')->get('Select Seat'); ?></a>
                        </div>
                        <?php if($trip->fleetType->facilities): ?>
                        <div class="ticket-item-footer">
                            <div class="d-flex content-justify-center">
                                <span>
                                    <strong><?php echo app('translator')->get('Facilities - '); ?></strong>
                                    <?php $__currentLoopData = $trip->fleetType->facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="facilities"><?php echo e(__($item)); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="ticket-item">
                        <h5><?php echo e(__($emptyMessage)); ?></h5>
                    </div>
                    <?php endif; ?>
                    <?php if($trips->hasPages()): ?>
                    <?php echo e(paginateLinks($trips)); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    (function($) {
        "use strict";
        $('.search').on('change', function() {
            $('#filterForm').submit();
        });

        $('.reset-button').on('click', function() {
            $('.search').attr('checked', false);
            $('#filterForm').submit();
        })
    })(jQuery)
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.$layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bus_ku\core\resources\views/templates/basic/ticket.blade.php ENDPATH**/ ?>