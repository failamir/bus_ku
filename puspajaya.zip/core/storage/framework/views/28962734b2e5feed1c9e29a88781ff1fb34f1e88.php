<?php $__env->startSection('content'); ?>
<div class="container padding-top padding-bottom">
    <div class="row justify-content-center gy-4">
        <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 col-xl-3">
            <div class="card cmn--card card-deposit">
                <div class="card-header text-center">
                    <h5 class="title"><?php echo e(__($data->name)); ?></h5>
                </div>
                <div class="card-body card-body-deposit">
                    <img src="<?php echo e($data->methodImage()); ?>" class="card-img-top" alt="<?php echo e(__($data->name)); ?>" class="w-100">
                </div>
                <div class="card-footer pt-0 pb-4">
                    <a href="javascript:void(0)" data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->name); ?>" data-currency="<?php echo e($data->currency); ?>" data-method_code="<?php echo e($data->method_code); ?>" data-base_symbol="<?php echo e($data->baseSymbol()); ?>" data-percent_charge="<?php echo e(showAmount($data->percent_charge)); ?>" data-booked_ticket="<?php echo e($bookedTicket); ?>" class=" btn btn--base w-100 deposit" data-bs-toggle="modal" data-bs-target="#depositModal">
                        <?php echo app('translator')->get('Pay Now'); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="modal fade" id="depositModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title method-name" id="depositModalLabel"></h5>
                <a href="javascript:void(0)" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <form action="<?php echo e(route('user.deposit.insert')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" name="currency" class="edit-currency">
                        <input type="hidden" name="method_code" class="edit-method-code">
                    </div>
                    <span><?php echo app('translator')->get('Are you sure, you want to payment via'); ?> <strong class="method-name font-weight-bold"></strong> ?</span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--danger w-auto btn--sm" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <div class="prevent-double-click">
                        <button type="submit" class="btn btn--success confirm-btn btn--sm"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    (function($) {
        "use strict";
        $('.deposit').on('click', function() {
            var bookedTicket = $(this).data('booked_ticket');
            var name = $(this).data('name');
            var currency = $(this).data('currency');
            var method_code = $(this).data('method_code');
            var baseSymbol = "<?php echo e($general->cur_text); ?>";

            $('.method-name').text(`<?php echo app('translator')->get('Payment By '); ?> ${name}`);
            $('.currency-addon').text(baseSymbol);
            $('.edit-currency').val(currency);
            $('.edit-method-code').val(method_code);
            $('#amount').val(parseFloat(bookedTicket.sub_total));
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bus_ku\core\resources\views/templates/basic/user/payment/deposit.blade.php ENDPATH**/ ?>