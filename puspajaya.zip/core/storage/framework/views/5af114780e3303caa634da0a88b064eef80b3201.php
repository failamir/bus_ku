<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH C:\laragon\www\bus_ku\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>