<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card b-radius--10 ">
                <div class="card-body">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Title'); ?></th>
                                    <th><?php echo app('translator')->get('AC / Non-AC'); ?></th>
                                    <th><?php echo app('translator')->get('Day Off'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Title'); ?>">
                                        <?php echo e(__($item->title)); ?>

                                    </td>

                                    <td data-label="<?php echo app('translator')->get('AC / Non-AC'); ?>">
                                        <?php echo e(__($item->fleetType->has_ac == 1 ? 'AC' : 'Non-Ac')); ?>

                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Day Off'); ?>">
                                        <?php if($item->day_off): ?>
                                            <?php $__currentLoopData = $item->day_off; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(__(showDayOff($day))); ?> <?php if(!$loop->last): ?> , <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php echo app('translator')->get('No Off Day'); ?>
                                        <?php endif; ?>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                        <?php if($item->status == 1): ?>
                                        <span class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Active'); ?></span>
                                        <?php else: ?>
                                        <span class="text--small badge font-weight-normal badge--warning"><?php echo app('translator')->get('Disabled'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <button type="button" class="icon-btn ml-1 editBtn"
                                                data-toggle="modal" data-target="#editModal"
                                                data-trip="<?php echo e($item); ?>"
                                                data-action="<?php echo e(route('admin.trip.update', $item->id)); ?>"
                                                data-original-title="<?php echo app('translator')->get('Update'); ?>">
                                            <i class="la la-pen"></i>
                                        </button>

                                        <?php if($item->status != 1): ?>
                                            <button type="button"
                                                class="icon-btn btn--success ml-1 activeBtn"
                                                data-toggle="modal" data-target="#activeModal"
                                                data-id="<?php echo e($item->id); ?>"
                                                data-trip_title = "<?php echo e($item->title); ?>"
                                                data-original-title="<?php echo app('translator')->get('Active'); ?>">
                                                <i class="la la-eye"></i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button"
                                                class="icon-btn btn--danger ml-1 disableBtn"
                                                data-toggle="modal" data-target="#disableModal"
                                                data-id="<?php echo e($item->id); ?>"
                                                data-trip_title = "<?php echo e($item->title); ?>"
                                                data-original-title="<?php echo app('translator')->get('Disable'); ?>">
                                                <i class="la la-eye-slash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($trips)); ?>

                </div>
            </div>
        </div>
    </div>


    
    <div id="addModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> <?php echo app('translator')->get('Add Trip'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.trip.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Title'); ?></label>
                            <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Enter Title'); ?>" name="title" required>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Fleet Type'); ?></label>
                            <select name="fleet_type" class="select2-basic fleet_type1" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $fleetTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Route'); ?></label>
                            <select name="route" class="select2-basic route1" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"  data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Schedule'); ?></label>
                            <select name="schedule" class="select2-basic schedule1" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e(showDateTime($item->start_from, 'h:i a').' - '. showDateTime($item->end_to, 'h:i a')); ?>"><?php echo e(__(showDateTime($item->start_from, 'h:i a').' - '. showDateTime($item->end_to, 'h:i a'))); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Start From'); ?></label>
                            <select name="start_from" class="select2-basic start_form1" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('End To'); ?></label>
                            <select name="end_to" class="select2-basic end_to1" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold" for="day_off"><?php echo app('translator')->get('Day Off'); ?></label>
                            <select class="select2-basic" name="day_off[]" id="day_off"  multiple="multiple" required>
                                <option value="0"><?php echo app('translator')->get('Sunday'); ?></option>
                                <option value="1"><?php echo app('translator')->get('Monday'); ?></option>
                                <option value="2"><?php echo app('translator')->get('Tuesday'); ?></option>
                                <option value="3"><?php echo app('translator')->get('Wednesday'); ?></option>
                                <option value="4"><?php echo app('translator')->get('Thursday'); ?></option>
                                <option value="5"><?php echo app('translator')->get('Friday'); ?></option>
                                <option value="6"><?php echo app('translator')->get('Saturday'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Save'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div id="editModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> <?php echo app('translator')->get('Update Trip'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Title'); ?></label>
                            <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Enter Title'); ?>" name="title" required>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Fleet Type'); ?></label>
                            <select name="fleet_type" class="select2-basic fleet_type2" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $fleetTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Route'); ?></label>
                            <select name="route" class="select2-basic route2" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"  data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Schedule'); ?></label>
                            <select name="schedule" class="select2-basic schedule2" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e(showDateTime($item->start_from, 'h:i a').' - '. showDateTime($item->end_to, 'h:i a')); ?>"><?php echo e(__(showDateTime($item->start_from, 'h:i a').' - '. showDateTime($item->end_to, 'h:i a'))); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Start From'); ?></label>
                            <select name="start_from" class="select2-basic start_from2" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('End To'); ?></label>
                            <select name="end_to" class="select2-basic end_to2" required>
                                <option value=""><?php echo app('translator')->get('Select an option'); ?></option>
                                <?php $__currentLoopData = $stoppages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>"><?php echo e(__($item->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label font-weight-bold" for="day_off_update"><?php echo app('translator')->get('Day Off'); ?></label>
                            <select class="select2-basic" name="day_off[]" id="day_off_update" multiple="multiple" required>
                                <option value="0"><?php echo app('translator')->get('Sunday'); ?></option>
                                <option value="1"><?php echo app('translator')->get('Monday'); ?></option>
                                <option value="2"><?php echo app('translator')->get('Tuesday'); ?></option>
                                <option value="3"><?php echo app('translator')->get('Wednesday'); ?></option>
                                <option value="4"><?php echo app('translator')->get('Thursday'); ?></option>
                                <option value="5"><?php echo app('translator')->get('Friday'); ?></option>
                                <option value="6"><?php echo app('translator')->get('Saturday'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Update'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div id="activeModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> <?php echo app('translator')->get('Active Trip'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.trip.active.disable')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="id" hidden="true">
                    <div class="modal-body">
                        <p><?php echo app('translator')->get('Are you sure to active'); ?> <span class="font-weight-bold trip_title"></span> <?php echo app('translator')->get('trip'); ?>?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Active'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div id="disableModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"> <?php echo app('translator')->get('Disable Trip'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.trip.active.disable')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="id" hidden="true">
                    <div class="modal-body">
                        <p><?php echo app('translator')->get('Are you sure to disable'); ?> <span class="font-weight-bold trip_title"></span> <?php echo app('translator')->get('trip'); ?>?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--danger"><?php echo app('translator')->get('Disable'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--Alert Modal -->
    <div class="modal fade" id="alertModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo app('translator')->get('Help Message'); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                <div class="modal-body">
                    <div class="container-fluid">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="javascript:void(0)" class="btn btn-sm btn--primary box--shadow1 text--small addBtn"><i class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?></a>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";

            $('#addModal').on('shown.bs.modal', function (e) {
                $(document).off('focusin.modal');
            });

            $('#editModal').on('shown.bs.modal', function (e) {
                $(document).off('focusin.modal');
            });

            $('.disableBtn').on('click', function () {
                var modal = $('#disableModal');
                modal.find('input[name=id]').val($(this).data('id'));
                modal.find('.trip_title').text($(this).data('trip_title'));
                modal.modal('show');
            });

            $('.activeBtn').on('click', function () {
                var modal = $('#activeModal');
                modal.find('input[name=id]').val($(this).data('id'));
                modal.find('.trip_title').text($(this).data('trip_title'));
                modal.modal('show');
            });

            $('.addBtn').on('click', function () {
                $('input[name=title]').text('')
                var modal = $('#addModal');
                modal.modal('show');
            });

            $('.editBtn').on('click', function () {
                var modal = $('#editModal');
                var trip = $(this).data('trip');
                modal.find('select[name=fleet_type]').data('name', trip.fleet_type.name);
                modal.find('select[name=route]').data('name',trip.route.name);
                modal.find('select[name=schedule]').data('name',trip.schedule.name);
                modal.find('select[name=start_from]').data('name',trip.start_from.name);
                modal.find('select[name=end_to]').data('name',trip.end_to.name);

                modal.find('form').attr('action' ,$(this).data('action'));
                modal.find('select[name=fleet_type]').val(trip.fleet_type_id);
                modal.find('select[name=route]').val(trip.vehicle_route_id);
                modal.find('select[name=schedule]').val(trip.schedule_id);
                modal.find('select[name=start_from]').val(trip.start_from);
                modal.find('select[name=end_to]').val(trip.end_to);
                modal.find('select[name="day_off[]"]').val(trip.day_off).select2();
                $('.select2-basic').select2();
                makeTitle('editModal');
                modal.modal('show');
            });

            $(document).on('change', '.start_from1, .end_to1, .fleet_type1', function () {
                makeTitle('addModal');
            });

            $(document).on('change', '.start_from2, .end_to2, .fleet_type2', function () {
                makeTitle('editModal');
            });


            function makeTitle(modalName){
                var modal = $('#'+ modalName);
                var data1 = modal.find('select[name="fleet_type"]').find("option:selected").data('name');
                var data2 = modal.find('select[name="start_from"]').find("option:selected").data('name');
                var data3 = modal.find('select[name="end_to"]').find("option:selected").data('name');
                var data  = [];
                var title = '';
                if(data1 != undefined){
                    data.push(data1);
                }
                if(data2 != undefined)
                    data.push(data2);
                if(data3 != undefined)
                    data.push(data3);
                if(data1 != undefined && data2 != undefined && data3 != undefined) {
                    var fleet_type_id = modal.find('select[name="fleet_type"]').val();
                    var vehicle_route_id = modal.find('select[name="route"]').val();

                    $.ajax({
                        type: "get",
                        url: "<?php echo e(route('admin.trip.ticket.check_price')); ?>",
                        data: {
                            "fleet_type_id" : fleet_type_id,
                            "vehicle_route_id" : vehicle_route_id
                        },
                        success: function (response) {
                            if(response.error){
                                modal.find('input').val('');
                                modal.find('select').val('').trigger('change');
                                modal.modal('hide');
                                var alertModal = $('#alertModal');
                                alertModal.find('.container-fluid').text(response.error);
                                alertModal.modal('show');
                            }
                        }
                    });
                }

                $.each(data, function (index, value) {
                    if(index > 0){
                        if(index > 3)
                            title += ' to ';
                        else
                            title += ' - ';
                    }
                    title += value;
                });
                $('input[name="title"]').val(title);
            }
        })(jQuery);
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bus_ku\core\resources\views/admin/trip/trip.blade.php ENDPATH**/ ?>