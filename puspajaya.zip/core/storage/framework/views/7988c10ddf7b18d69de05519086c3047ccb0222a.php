<!-- Preloader -->
<div class="preloader">
    <div class="loader-wrapper">
        <div class="truck-wrapper">
            <div class="preloader-content"><?php echo e(__($general->sitename)); ?></div>
            <div class="truck">
            <div class="truck-container"></div>
            <div class="glases"></div>
            <div class="bonet"></div>

            <div class="base"></div>

            <div class="base-aux"></div>
            <div class="wheel-back"></div>
            <div class="wheel-front"></div>
            <div class="smoke"></div>
            </div>
        </div>
    </div>
</div>
<!-- Preloader -->
<?php /**PATH C:\laragon\www\bus_ku\core\resources\views/templates/basic/partials/preloader.blade.php ENDPATH**/ ?>