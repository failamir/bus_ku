<?php
    $amenitiesContent = getContent('amenities.content', true);
    $facilities = getContent('amenities.element',false,null,true);
?>
<!-- Our Ameninies Section Starts Here -->
<section class="amenities-section padding-bottom">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-10">
                <div class="section-header text-center">
                    <h2 class="title"><?php echo e(__(@$amenitiesContent->data_values->heading)); ?></h2>
                    <p><?php echo e(__(@$amenitiesContent->data_values->sub_heading)); ?></p>
                </div>
            </div>
        </div>
        <div class="amenities-wrapper">
            <div class="amenities-slider">
                <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-slider">
                    <div class="amenities-item">
                        <div class="thumb">
                            <?php
                                echo $item->data_values->icon
                            ?>
                        </div>
                        <h6 class="title"><?php echo e(__($item->data_values->title)); ?></h6>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Our Ameninies Section Ends Here -->
<?php /**PATH C:\laragon\www\bus_ku\core\resources\views/templates/basic/sections/amenities.blade.php ENDPATH**/ ?>