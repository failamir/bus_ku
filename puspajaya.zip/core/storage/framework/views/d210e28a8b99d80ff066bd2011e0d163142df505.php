<?php $__env->startSection('content'); ?>
    <?php
        $content = getContent('sign_in.content', true);
    ?>
    <!-- Account Section Starts Here -->
    <section class="account-section bg_img" style="background: url(<?php echo e(getImage('assets/images/frontend/sign_in/'. @$content->data_values->background_image, "1920x1280")); ?>) bottom left;">
        <span class="spark"></span>
        <span class="spark2"></span>
        <div class="account-wrapper">
            <div class="account-form-wrapper">
                <div class="account-header">
                    <div class="left-content">
                        <div class="logo mb-4">
                            <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'].'/logo.png')); ?>" alt="Logo"></a>
                        </div>
                         <h3 class="title"><?php echo e(__(@$content->data_values->heading)); ?></h3>
                        <span><?php echo e(__(@$content->data_values->sub_heading)); ?></span>
                    </div>
                </div>
                    <form method="POST" class="account-form row" action="<?php echo e(route('user.login')); ?>" onsubmit="return submitUserForm();">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-12">
                        <div class="form--group">
                            <label for="username"><?php echo app('translator')->get('Username'); ?></label>
                            <input id="username" name="username" type="text" class="form--control" placeholder="<?php echo app('translator')->get('Enter Your username'); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form--group">
                            <label for="password"><?php echo app('translator')->get('Password'); ?></label>
                            <input id="password" type="password" name="password" class="form--control" placeholder="<?php echo app('translator')->get('Enter Your Password'); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form--group">
                            <?php echo loadReCaptcha() ?>
                        </div>
                    </div>
                    <?php echo $__env->make($activeTemplate.'partials.custom_captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-lg-12 d-flex justify-content-between">
                        <div class="form--group custom--checkbox">
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label for="remember"><?php echo app('translator')->get('Remember Me'); ?></label>
                        </div>
                        <div class="">
                            <a href="<?php echo e(route('user.password.request')); ?>"><?php echo app('translator')->get('Forgot Password?'); ?></a>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form--group">
                            <button class="account-button w-100" type="submit"><?php echo app('translator')->get('Log In'); ?></button>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="account-page-link">
                            <p><?php echo app('translator')->get('Don\'t have any Account?'); ?> <a href="<?php echo e(route('user.register')); ?>"><?php echo app('translator')->get('Sign Up'); ?></a></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <!-- Account Section Ends Here -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span class="text-danger"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.authenticate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bus_ku\core\resources\views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>