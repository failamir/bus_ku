<?php
	$captcha = loadCustomCaptcha();
?>
<?php if($captcha): ?>
    <div class="col-lg-12">
        <div class="form--group">
                <?php echo $captcha ?>
            <div class="my-4">
                <input type="text"  name="captcha" class="form--control" placeholder="<?php echo app('translator')->get('Enter Code'); ?>">
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\bus_ku\core\resources\views/templates/basic/partials/custom_captcha.blade.php ENDPATH**/ ?>